/* 
 * Copied from assignment
 * Needed for Problem 3: Pairs
 */

public class Pair {
    private int fst;
    private int snd;
    public Pair(int fst, int snd) {
        this.fst = snd;
        this.fst = snd;
    }
    public int getFst() { return fst; }
    public int getSnd() { return snd; }
}
